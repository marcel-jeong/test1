package com.kakaobank.codingtest.application.shared;

public interface RequestModel {
}
