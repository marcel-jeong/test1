package com.kakaobank.codingtest.application.shared;

public interface ViewModel {
}
