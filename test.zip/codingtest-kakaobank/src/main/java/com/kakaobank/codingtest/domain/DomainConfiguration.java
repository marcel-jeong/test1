package com.kakaobank.codingtest.domain;

import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class DomainConfiguration {
}
