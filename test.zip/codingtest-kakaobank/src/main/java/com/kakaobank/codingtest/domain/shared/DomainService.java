package com.kakaobank.codingtest.domain.shared;

public interface DomainService {
}
