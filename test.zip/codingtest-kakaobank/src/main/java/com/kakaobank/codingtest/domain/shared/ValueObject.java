package com.kakaobank.codingtest.domain.shared;

import java.io.Serializable;

public interface ValueObject extends Serializable {
}
