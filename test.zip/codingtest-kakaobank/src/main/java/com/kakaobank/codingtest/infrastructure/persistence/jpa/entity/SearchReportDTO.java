package com.kakaobank.codingtest.infrastructure.persistence.jpa.entity;

public interface SearchReportDTO {
    String getKeyword();

    Long getCount();
}
